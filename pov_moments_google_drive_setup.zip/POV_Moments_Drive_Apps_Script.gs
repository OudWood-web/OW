/**
 * POV Moments — Google Drive upload endpoint
 * Folder tujuan sudah diisi sesuai link Google Drive pengguna.
 *
 * PENTING:
 * 1. Buka https://script.google.com/ dan buat project baru.
 * 2. Tempel kode ini di Code.gs.
 * 3. Deploy > New deployment > Web app.
 * 4. Execute as: Me.
 * 5. Who has access: Anyone (atau pilihan akses yang sesuai kebutuhan).
 * 6. Salin URL Web app berakhiran /exec dan tempel ke konstanta
 *    DRIVE_UPLOAD_ENDPOINT di file HTML.
 *
 * Catatan keamanan: endpoint "Anyone" dapat menerima unggahan dari siapa pun
 * yang memiliki URL. Bagikan URL situs hanya kepada tamu yang diizinkan dan
 * pertimbangkan pembatasan ukuran/jumlah unggahan untuk acara publik.
 */
const TARGET_FOLDER_ID = '1T9cY5FAOQHv8Axvu1--CEijVpb_uXyR6';

function doPost(e) {
  try {
    const payload = JSON.parse((e.postData && e.postData.contents) || '{}');
    const folderId = payload.folderId || TARGET_FOLDER_ID;
    if (folderId !== TARGET_FOLDER_ID) {
      throw new Error('Folder tujuan tidak diizinkan.');
    }
    if (!payload.base64) throw new Error('Data foto kosong.');

    // Batasi payload sekitar 8 MB base64 untuk mengurangi risiko timeout.
    if (payload.base64.length > 8 * 1024 * 1024) {
      throw new Error('Foto terlalu besar. Coba unggah foto yang lebih kecil.');
    }

    const bytes = Utilities.base64Decode(payload.base64);
    const safeName = String(payload.filename || ('pov-' + Date.now() + '.jpg'))
      .replace(/[\\/:*?"<>|#%{}~&]/g, '_')
      .slice(0, 120);
    const mimeType = payload.mimeType === 'image/png' ? 'image/png' : 'image/jpeg';
    const blob = Utilities.newBlob(bytes, mimeType, safeName);
    const folder = DriveApp.getFolderById(TARGET_FOLDER_ID);
    const file = folder.createFile(blob);
    return ContentService
      .createTextOutput(JSON.stringify({ok: true, fileId: file.getId(), name: file.getName()}))
      .setMimeType(ContentService.MimeType.JSON);
  } catch (err) {
    return ContentService
      .createTextOutput(JSON.stringify({ok: false, error: String(err)}))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

function doGet() {
  return ContentService
    .createTextOutput('POV Moments upload endpoint aktif.')
    .setMimeType(ContentService.MimeType.TEXT);
}
